/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *next;
};
void triversal(struct node *ptr){
    while(ptr != NULL){
        printf("Data:%d ",ptr->data);
        ptr=ptr->next;
    }
}

int isEmpty(struct node *top){
    if(top==NULL){
        return 1;
    }else{
        return 0;
    }
}

int isFull(struct node *top){
    struct node *n=(struct node*)malloc(sizeof(struct node));
    if(n==NULL){
        return 1;
    }else{
        return 0;
    }
}

struct node* push(struct node *top,int value){
    
    if(isFull(top)){
        printf("Over flow stack :)\n");
    }else{
        struct node *x=(struct node*)malloc(sizeof(struct node));
        x->data=value;
        x->next=top;
        top=x;
        return top;
    }
}

int pop(struct node** top){
    if(isEmpty(*top)){
          printf("Over under flow stack :)\n");
    }else{
        struct node *x=*top;
        *top=(*top)->next;
        int val=x->data;
        free(x);
       
        return val;
    }
}

int main()
{
    struct node *top=NULL;
  top=push(top,23);
  top=push(top,73);
  top=push(top,93);
   top=push(top,99);
  
  
 
  triversal(top);
  int element=pop(&top);
  
  
  printf("\nElement is poped=%d\n",element);
  triversal(top);
    
   

    return 0;
}
