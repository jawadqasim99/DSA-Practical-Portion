/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node *next;
}*hnode;



void createNode(int n){
    struct node *temp,*fnnode;
    int i,num;
    hnode=(struct node *)malloc(sizeof(struct node));
    if(hnode==NULL){
        printf("Memoery Allocation is NULL :)\n");
       
    }else{
         printf("Enter a number 1: ");
    scanf("%d",&num);
    hnode->data=num;
    hnode->next=NULL;
    temp=hnode;
       
    for(i=2;i<=n;i++){
         fnnode=(struct node *)malloc(sizeof(struct node));
         if(fnnode==NULL){
        printf("Memoery Allocation is NULL :)\n");
       
    }else{
         printf("Enter a number %d: ",i);
    scanf("%d",&num);
    fnnode->data=num;
       fnnode->next=NULL;
    temp->next=fnnode;

   
    temp=temp->next;
    } 
    }
    printf("link is created\n");
    
    }
   
 
}
void display(struct node *ptr){
   
   
    while(ptr!=NULL){
        printf("Data:%d ",ptr->data);
        ptr=ptr->next;
    }
}
int isFull(struct node* top){
    struct node *n=(struct node *)malloc(sizeof(struct node));
    if(n==NULL){
        
        return 1;
        
    }else{
        return 0;
    }
}

struct node* push(struct node* top){
    struct node *x=(struct node *)malloc(sizeof(struct node));
    int num;
    if(isFull(top)){
        printf("Over flow");
    }else{
        printf("\nEnter a number: ");
        scanf("%d",&num);
       x->data= num;
       x->next=top;
       top=x;
       return top;
    }
}

int main()
{
  
    
   int n;
   printf("Enter a number of node: ");
   scanf("%d",&n);
   createNode(n);
display(hnode);
hnode=push(hnode);
hnode=push(hnode);


display(hnode);

    return 0;
}


