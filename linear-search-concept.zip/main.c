/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int linearSearch(int arr[],int size,int element){
    for(int i=0;i<size;i++){
        if(arr[i]==element){
             return i;
        }
       
       
         
    }
      return -1;
    
   
}
void found(int searcIndex,int element){
    if(searcIndex==-1){
        printf("element does not exixt ");
    }else
 printf("The elemnt %d is found in this index %d ",element,searcIndex);
}

int main()
{
   int arr[50]={3,3,4,3,2,4,5,12,34,54,34,543,24,5432,2424,54324,2435};
  int size=sizeof(arr)/sizeof(int);
   int element;
   printf("Plz Eneter elemnet=");
   scanf("%d",&element);
  int searcIndex= linearSearch(arr,size,element);
  found(searcIndex,element);
 

    return 0;
}
