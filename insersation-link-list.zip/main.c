/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};

void trivers(struct node *ptr){
    while(ptr!=NULL){
        printf("Element=%d ",ptr->data);
        ptr=ptr->next;
    }
}


// insert a node at the 1st node in the list

struct node * insertnode(struct node *head,int values){
    struct node *ptr=(struct node *)malloc(sizeof(struct node));
    ptr->next=head;
    ptr->data=values;
    return ptr;
}

// insert a node to the index of list
struct node * insetIndexList(struct node *ptr,int value,int index){
    struct node *prevNode=(struct node *)malloc(sizeof(struct node));
    struct node *p;
    p=ptr;
    int i=0;
    while(i!=index-1)
    {
        p=p->next;
        i++;
    }
    prevNode->data=value;
    prevNode->next=p->next;
    p->next=prevNode;
    
    printf("\nData is insert\n");
    return ptr;
    
    
    
}
// isert node at the end of list;

struct node * lastNodeInsert(struct node *head,int value){
    struct node *ptr=(struct node *)malloc(sizeof(struct node));
    struct node *p=head;
    while(p->next!=NULL){
        p=p->next;
        
    }
    ptr->data=value;
    p->next=ptr;
 
    ptr->next=NULL;
       return head;
}

// insert a node of given node that inset after of this node;

struct node * givenNode(struct node *head,struct node *prevNode,int value){
    struct node *ptr=(struct node *)malloc(sizeof(struct node));
    ptr->data=value;
   ptr->next=prevNode->next;
   prevNode->next=ptr;
    
    
       return head;
}


   int main()
{
   struct node * head;
    struct node * second;
     struct node * third;
     int index=2,value=34;
   head=(struct node *)malloc(sizeof(struct node));
   second=(struct node *)malloc(sizeof(struct node));
   third=(struct node *)malloc(sizeof(struct node));
   head->data=3;
   head->next=second;
   second->data=4;
   second->next=third;
   third->data=5;
   third->next=NULL;
  printf("Link list before created\n");
  trivers(head);
//   head=insertnode(head,value);
// head=insetIndexList(head,value,index);
// head=lastNodeInsert(head,value);
head=givenNode(head,second,value);
  printf("\nInsert a node at the first\n");
   trivers(head);
  
 

    return 0;
}






