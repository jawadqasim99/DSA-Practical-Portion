#include<stdio.h>
#include<stdlib.h>
struct stack
{
  int size;
  int top;
  int *arr;
};
int
isEmpty (struct stack *ptr)
{
  if (ptr->top == -1)
    {
      return 1;
    }
  else
    {
      return 0;
    }
}

void
push (struct stack *ptr, int value)
{

  if (ptr->top == ptr->size - 1)
    {
      printf ("Arr is full");
    }
  ptr->top++;
  ptr->arr[ptr->top] = value;
  printf ("element push\n");

}

int
pop (struct stack *ptr)
{

  if (ptr->top == -1)
    {
      printf ("Arr is Empty\n");
      return -1;
    }
  ptr->top--;
  return ptr->arr[ptr->top];

}

int
main ()
{
  struct stack *s;
  int value, choice,popValue;

  s = (struct stack *) malloc (sizeof (struct stack));

  if (s == NULL)
    {
      printf ("Memory is not allocated :)");
      return 1;
    }

  s->size = 8;
  s->top = -1;
  s->arr = (int *) malloc (s->size * sizeof (int));
  if (s->arr == NULL)
    {
      printf ("stack memory is not allocated :)");
      free (s);
      return 1;
    }

  while (1)
    {

      printf ("1:Push || 2:Pop || 3:Exit\n");
      printf("Enetr your choice= ");
      scanf ("%d", &choice);
      switch (choice)
	{
	case 1:
	  printf ("Enter element that push in Arr: ");
	  scanf ("%d", &value);
	  push (s, value);
	  break;
	case 2:
	popValue=  pop (s);
	if(popValue != -1){
	    printf("Poped valuse :%d ",popValue);
	}
	break;
	
	case 3:
	  exit (0);
	default:
	  printf ("\nInvaild Input\n");
	}
    }

  return 0;

}
