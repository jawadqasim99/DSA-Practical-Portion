/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};

void trivers(struct node *head){
    struct node *ptr=head;
   do{
       printf("Element=%d ",ptr->data);
       ptr=ptr->next;
       
   }
   while(ptr!=head);
}

// add node at the first

struct node * firstNode(struct node *head,int value){
    struct node *ptr=(struct node *)malloc(sizeof(struct node));
    ptr->data=value;
    struct node *p=head->next;
    while(p->next!=head){
        p=p->next;
    }
    p->next=ptr;
    ptr->next=head;
    head=ptr;
    return head;
}



   int main()
{
   struct node * head;
    struct node * second;
     struct node * third;
     int index=2,value=34;
   head=(struct node *)malloc(sizeof(struct node));
   second=(struct node *)malloc(sizeof(struct node));
   third=(struct node *)malloc(sizeof(struct node));
   head->data=3;
   head->next=second;
   second->data=4;
   second->next=third;
   third->data=5;
   third->next=head;
  printf("Link list before created\n");
  trivers(head);
  
  head=firstNode(head,value);
  printf("\nAdded a node\n");
  trivers(head);


    return 0;
}






