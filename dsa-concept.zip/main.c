/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

// Online C compiler to run C program online
#include<stdio.h>
void
showarr (int arr[], int n)
{
  for (int i = 0; i < n; i++)
    {
      printf ("%d ", arr[i]);
//   printf("\n");
    }

}

int
insertvalu (int arr[], int size, int element, int capacity, int index)
{
  if (size >= capacity)
    {
      printf ("Number is accessd..");
      return -1;
    }
  else
    {
      for (int i = size - 1; i >= index; i--)
	{
	  arr[i + 1] = arr[i];
	}
      arr[index] = element;
      printf ("\n");
      return 1;

    }
}




int
main ()
{
  int arr[100] = { 2, 3, 4, 5, 6 };
  int size = 5, index = 2, element = 43;
  showarr (arr, size);
  insertvalu (arr, size, element, 100, index);
  size += 1;
  showarr (arr, size);
  return 0;
}
