/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct node {
    int data;
    struct node *next;
}*snnode;
void createNodeList(int n){
    struct node *fnnode,*temp;
    int i,num;
    snnode=(struct node * )malloc(sizeof(struct node));
    if(snnode==NULL){
        printf("Memoery Doesnot exixt!!");
    }else{
        printf("Enter a data of 1 node=");
        scanf("%d",&num);
        snnode->data=num;
        snnode->next=NULL;
        temp=snnode;
        for(i=2;i<=n;i++){
        fnnode=(struct node *)malloc(sizeof(struct node));
        if(fnnode==NULL){
        printf("Memoery Doesnot exixt!!");
        break;
    }else{
              printf("Enter data %d =",i);
        scanf("%d",&num);
        fnnode->data=num;
        fnnode->next=NULL;
        temp->next=fnnode;
        temp=temp->next;  
    }

    }
    
    printf("List created!!\n");
        
    }
    
}
void delelist(){
     struct node *dellist;
    if(snnode==NULL){
        printf("\nNode is empty!");
    }else{
        
    dellist=snnode;
    snnode=snnode->next;
    printf("delete 1st node");
    free(dellist);
    }
   
}
void createNodeList(int n){
    struct node *fnnode,*temp;
    int i,num;
    snnode=(struct node * )malloc(sizeof(struct node));
    if(snnode==NULL){
        printf("Memoery Doesnot exixt!!");
    }else{
        printf("Enter a data of 1 node=");
        scanf("%d",&num);
        snnode->data=num;
        snnode->next=NULL;
        temp=snnode;
        for(i=2;i<=n;i++){
        fnnode=(struct node *)malloc(sizeof(struct node));
        if(fnnode==NULL){
        printf("Memoery Doesnot exixt!!");
        break;
    }else{
              printf("Enter data %d =",i);
        scanf("%d",&num);
        fnnode->data=num;
        fnnode->next=NULL;
        temp->next=fnnode;
        temp=temp->next;  
    }

    }
    
    printf("List created!!\n");
        
    }
    
}
void delelist(){
     struct node *dellist;
    if(snnode==NULL){
        printf("\nNode is empty!");
    }else{
        
    dellist=snnode;
    snnode=snnode->next;
    printf("delete 1st node");
    free(dellist);
    }
   
}
void display()
{
    struct node *temp;

    /*
     * If the list is empty i.e. head = NULL
     */
    if(snnode == NULL)
    {
        printf("List is empty.");
    }
    else
    {
        temp = snnode;
        while(temp != NULL)
        {
            printf("Data = %d\n", temp->data); // Print data of current node
            temp = temp->next;                 // Move to next node
        }
    }
}




int main()
{
    int n;
    printf("Enter No of node:");
    scanf("%d",&n);
    createNodeList(n);
    display();
    delelist();
    display();
    return 0;
}
