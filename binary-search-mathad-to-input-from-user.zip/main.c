/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
}*snnode;
void createNodeList(int n){
    struct node *fnnode,*temp;
    int num,i;
    snnode=(struct node *)malloc(sizeof(struct node));
    if(snnode == NULL){
        printf("Memoery in not loccted!");
        return;
    }else{
        printf("input number for node 1 =");
        scanf("%d",&num);
        snnode->data=num;
        snnode->next=NULL;
        temp=snnode;
    }
    
    for(i=2;i<=n;i++){
        fnnode=(struct node *)malloc(sizeof(struct node));
        if(fnnode == NULL){
        printf("Memoery in not loccted!");
        return;
    }else{
        printf("input number for node %d =",i);
        scanf("%d",&num);
        fnnode->data=num;
        fnnode->next=NULL;
        temp->next=fnnode;
        temp=temp->next;
    }
    }
    
}

void display(){
    int ctr =0;
    while(snnode != NULL){
        ctr++;
        printf("element=%d ",snnode->data);
       snnode=snnode->next;
        
    }
    printf("\nTotal number of element is %d",ctr);
}
// void reverseNodeList(){
//     struct node *preNode,*curNode;
//     if(snnode != NULL){
//     preNode=snnode;
//     curNode=snnode->next;
//     snnode=snnode->next;
    
//     preNode->next=NULL;
    
//     while(snnode != NULL){
//         snnode=snnode->next;
//         curNode->next=preNode;
//         preNode=curNode;
//         curNode=snnode;
       
//     }
//      snnode=preNode;
//     }
// }
// int countNode(){
//     int ctr=0;
//     struct node *temp;
//     temp=snnode;
//     while(temp != NULL){
//         ctr++;
//         temp=temp->next;
       
//     }
//     return ctr;
// }
int main()
{
    
   int n,countdata;
   printf("Enter a number of node= ");
   scanf("%d",&n);
   createNodeList(n);
   display();
//     countdata=countNode();
//   printf(" \nTotal number of element %d",countdata);

    return 0;
}