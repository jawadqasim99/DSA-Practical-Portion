/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
struct queue{
    int size;
    int f;
    int b;
    int *arr;
};
int isEmpty(struct queue *ptr){
   return ptr->f==ptr->b;
}
int isFull(struct queue *ptr) {
return ptr->b == ptr->size - 1;
}

void enqueue(struct queue *ptr , int value){
    if(!isFull(ptr)){
       ptr->b++;
       ptr->arr[ptr->b]=value;
       printf("Value is inserted :)\n");
    }else{
         printf("Queue is overflow");
    }
}

int deque(struct queue *ptr){
  int a=-1;
    if(!isEmpty(ptr)){
        ptr->f++;
        a=ptr->arr[ptr->f];
    }else{
        printf("under Flow :)\n");
    }
    return a;
}

void triversal(struct queue *ptr){
     int i =ptr->f;
     i++;
    while(i<=ptr->b){
        printf("Value %d\n",ptr->arr[i]);
       i++;
        
    }
}

int peekValue(struct queue *ptr,int position){
    int i=ptr->f;
    i++;
   
    if(position>ptr->b){
      return 2;
        
    }else{
         while(i<=position){
        
        
        if(i==position){
            return ptr->arr[i];
        }
        i++;
    }
     
    }
    return 0;
 
   
}

int main()
{
   struct queue q;
   q.size=4;
   q.f=q.b=-1;
   q.arr=(int *)malloc(q.size * sizeof(int));
   int value =2;
   
//   if(isEmpty(&q)){
//       printf("Queue is under flow :)\n");
//   }else{
//       printf("Queue is not empty :)\n");
//   }
//     if(isFull(&q)){
//       printf("Queue is over flow :)\n");
//   }else{
//       printf("Queue is not full :)\n");
//   }

  enqueue(&q,14);
  enqueue(&q,89);
  enqueue(&q,34);
  triversal(&q);
  int updated=peekValue(&q,value);
  switch(updated){
      case 0:
      printf("Value is not found :)\n");
      break;
      case 2:
       printf("Position is overflow\n");
       break;
       default:
       printf("Peek value is %d",peekValue(&q,value)); 
       
}
    
   
  

  free(q.arr);

    return 0;
}




