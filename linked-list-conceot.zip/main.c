/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node * next; //self referncing structure
    
};
void triversal(struct node * ptr){
    while(ptr!=NULL){
        printf("elemnt=%d \n",ptr->data);
      ptr= ptr->next;
    }
}
// delet arry a first node in linl list 
struct node * dellist(struct node *head){
    struct node *ptr;
    ptr=head;
    head=head->next;
    free(ptr);
    return head;
    
}
// delet node accroding index 
struct node * nodeInputdel(struct node * head,int index){
    struct node *p,*q;
    p=head;
    q=p->next;
    for( int i=0;i<index-1;i++){
        p=p->next;
        q=q->next;
    }
    p->next=q->next;
    printf("Node data is deleted %d\n",q->data);
    free(q);
    
    return head;
}
// delet arry at the last index 

struct node * lastNodeDeleted(struct node * head){
    struct node *p,*q;
    p=head;
    q=p->next;
    while(q->next != NULL){
        p=p->next;
        q=q->next;
    }
    p->next=NULL;
    printf("Node data is deleted %d\n",q->data);
    free(q);
    
    return head;
}

// deleted node of given value
struct node * givenValuesNode(struct node * head,int value){
    struct node *p,*q;
    p=head;
    q=p->next;
   while(q->data != value && q->next != NULL){
        p=p->next;
        q=q->next;
    }
    if(q->data == value){
         p->next=q->next;
    printf("Node data is deleted %d\n",q->data);
    free(q);
    }
    printf("Vlaue doesnot exixt\n");
   
    
    return head;
}
int main()
{
   struct node * head;
    struct node * second;
     struct node * third;
     int index=2,value=0;
   head=(struct node *)malloc(sizeof(struct node));
   second=(struct node *)malloc(sizeof(struct node));
   third=(struct node *)malloc(sizeof(struct node));
   head->data=3;
   head->next=second;
   second->data=4;
   second->next=third;
   third->data=5;
   third->next=NULL;
  printf("Link list before created\n");
   triversal(head);
   
//   head= dellist(head);
// head=nodeInputdel(head,index);
// head=lastNodeDeleted(head);
head=givenValuesNode(head,value);
  printf("link list aftre delete!!\n");
   triversal(head);

    return 0;
}

