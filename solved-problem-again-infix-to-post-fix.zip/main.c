/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
   
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
  struct stack
{
  
int size;
   
int top;
   
char *arr;
 
};

 
int
isEmpty (struct stack *ptr)
{
  
if (ptr->top == -1)
    {
      
 
return 1;
    
}
  else
    {
      
return 0;
    
}

 
}


 
 
int
isFull (struct stack *ptr)
{
  
if (ptr->top == ptr->size - 1)
    {
      
printf ("Stack is OverFlow");
      
return 1;
    
}
  
  else
    {
      
return 0;
    
}

}


char
isTop (struct stack *ptr)
{
  
return ptr->arr[ptr->top];

}


 
void
triversal (struct stack *ptr)
{
  
int i = 0;
  
while (i <= ptr->top)
    {
      
printf ("elemnt %c", ptr->arr[i]);
      
i++;
    
}

}


 
void
push (struct stack *ptr, char val)
{
  
if (isFull (ptr))
    {
      
printf ("Under Flow Stack :)\n");
    
}
  else
    {
      
ptr->top++;
      
ptr->arr[ptr->top] = val;
    
}

}


char
pop (struct stack *ptr)
{
  
if (isEmpty (ptr))
    {
      
printf ("Under Flow Stack :)\n");
      
return 1;
    
}
  else
    {
      
char ch = ptr->arr[ptr->top];
      
ptr->top--;
      
return ch;
    
}

}


int
isopreator (char a)
{
  
if (a == '*' || a == '+' || a == '-' || a == '/')
    {
      
return 1;
    
}
  else
    
    {
      
return 0;
    
}

}


int
prasidance (char a)
{
  
if (a == '*' || a == '/')
    
return 3;
  
  else if (a == '+' || a == '-')
    
return 2;
  
  else
    
return 0;

}


char *
infPost (struct stack *sp, char *infix)
{
  
char *postFix = (char *) malloc ((strlen (infix) + 1) * sizeof (char));
  
int i = 0;
  
int j = 0;
  
while (infix[i] != '\0')
    {
      
if (!isopreator (infix[i]))
	{
	  
postFix[j] = infix[i];
	  
i++;
	  
j++;
	
}
      else if (prasidance (infix[i]) > prasidance (isTop (sp)))
	{
	  
push (sp, infix[i]);
	  
i++;
	
 
}
      else
	{
	  
postFix[j] = pop (sp);
	  
j++;
	
}
    
}
  
while (!isEmpty (sp))
    {
      
postFix[j] = pop (sp);
      
j++;
    
}
  
postFix[j] = '\0';
  
return postFix;

 
 
}


 
int
main () 
{
  
struct stack *sp = (struct stack *) malloc (sizeof (struct stack));
  
sp->size = 90;
  
sp->top = -1;
  
sp->arr = (char *) malloc (sp->size * sizeof (char));
  
char *infix = (char *) malloc (10 * sizeof (char));
  
printf ("Enter expression:");
  
scanf ("%s", infix);
  
printf ("postfix is %s", infPost (sp, infix));
  
return 0;
  
 
 
return 0;

}


