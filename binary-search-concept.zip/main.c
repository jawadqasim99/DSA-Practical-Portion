/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int binarysearch(int arr[],int size,int element){
    int low,mid,high;
    low=0;
    high=size-1;
    while(low<=high){
    mid=(low+high)/2;
    if(arr[mid]==element){
        return mid;
    }
   
   
    if(arr[mid]<element){
        low=mid+1;
    }else{
        high=mid-1;
    }
    }
    return -1;
    
    
}

int main()
{
    int arr[]={2,3,4,5,6,7,34,43,56,78,100,102,104};
    int size=sizeof(arr)/sizeof(int);
    int element=1000;
   int searchindex= binarysearch(arr,size,element);
   printf("The element %d is an index of %d ",element,searchindex);

    return 0;
}
