/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *prve;
    struct node *next;
};

void trivers(struct node *ptr){
    while(ptr!=NULL){
        printf("Element=%d ",ptr->data);
        ptr=ptr->next;
    }
}




   int main()
{
   struct node * head;
    struct node * second;
     struct node * third;
     int index=2,value=34;
   head=(struct node *)malloc(sizeof(struct node));
   second=(struct node *)malloc(sizeof(struct node));
   third=(struct node *)malloc(sizeof(struct node));
   head->data=3;
   head->prve=NULL;
   head->next=second;
   
   
   second->data=4;
   second->prve=head;
   second->next=third;
   
   
   third->data=5;
   third->prve=second;
   third->next=NULL;
  printf("Link list before created\n");
trivers(head);
  
 

    return 0;
}






