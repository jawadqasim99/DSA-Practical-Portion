#include<stdio.h>
#include<stdlib.h>

#define MAX 5
int stack[MAX];
int top=-1;

// push function to insert elment in array =>
void push(int value){
    
    if(top==MAX-1){
        printf("Error: Stack is overflow :)\n");
        return;
    }
    stack[top++]=value;
}

// pop function in array of stack =>

int pop(){
    if(top==-1){
        printf("Error: Stack is underflow :)\n");
        return -1;
    }
    return stack[top--];
}

int main(){
int choice,value;

while(1){
    printf("Enter:\n1:Push\n2:Pop\n3:Exit\n");
       printf("Enter your choice: ");
    scanf("%d",&choice);
    switch(choice){
        case 1:
                printf("Enter value to push: ");
                scanf("%d", &value);
                push(value);
                break;

            case 2:
                value = pop();
                if (value != -1) {
                    printf("Popped value: %d\n", value);
                }
                break;

            case 3:
                exit(0);

            default:
                printf("Invalid choice!\n");
    }
}
return 0;
}