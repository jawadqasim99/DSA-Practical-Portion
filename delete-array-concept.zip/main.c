/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void display(int arr[],int size){
    for(int i=0 ; i<size;i++){
        printf("%d ",arr[i]);
    }
    
}

void deletArr(int arr[],int size,int index){
    for(int i=index;i<size-1;i++){
        arr[i]=arr[i+1];
        printf("\n");
    }
}

int main()
{
    int arr[100]={2,3,4,5,6,7};
    int size=6,index=2;
    display(arr,size);
    deletArr(arr,size,index);
    size -=1;
    display(arr,size);

    return 0;
}
